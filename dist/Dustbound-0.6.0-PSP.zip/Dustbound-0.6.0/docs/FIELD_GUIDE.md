# Dustbound field guide — 0.6.0

The 25 chapters below match the in-game guide. ![select](../assets/ui/select.svg) inside a menu opens its contextual chapter.

## 1. Controls

![dpad](../assets/ui/dpad.svg) or analog: move in screen direction. ![cross](../assets/ui/cross.svg): nearby interaction. ![triangle](../assets/ui/triangle.svg): pack. ![square](../assets/ui/square.svg): fight/passive. ![circle](../assets/ui/circle.svg): sneak. ![l](../assets/ui/l.svg): next squad member. ![r](../assets/ui/r.svg): tactical pause. ![select](../assets/ui/select.svg): world atlas. ![start](../assets/ui/start.svg): expedition menu.

Menus pause the world. ![select](../assets/ui/select.svg) inside a menu opens its guide. ![l](../assets/ui/l.svg)/![r](../assets/ui/r.svg) switch inventory tabs or guide pages. Hold ![l](../assets/ui/l.svg) and tap ![cross](../assets/ui/cross.svg) to cycle nearby targets. Move to cancel work or travel.

## 2. Your Drifter

New expedition opens character creation. Choose a name, origin, ancestry, body, skin, hairstyle, hair color, beard and scars. ![horizontal](../assets/ui/horizontal.svg) adjusts each choice; ![cross](../assets/ui/cross.svg) edits your name or begins.

Origins change equipment, supplies and skills. Outlaws begin with a bounty. Caravan starts three companions. Ancestry changes starting strengths. A town barber can change your appearance later.

## 3. The Borderlands

The 1536 by 1536 borderlands contain sixteen settlements and nine terrain regions. Roads connect towns. Rivers have fords near roads; hills rise into mesas and snowfields.

![select](../assets/ui/select.svg) opens the atlas. Move the cursor; ![cross](../assets/ui/cross.svg) orders travel. ![triangle](../assets/ui/triangle.svg) switches local/world views. ![l](../assets/ui/l.svg)/![r](../assets/ui/r.svg) selects known towns. ![square](../assets/ui/square.svg) reveals surveyed geography after buying a chart. Town ownership, prosperity and unrest change with world events. Camps and depleted deposits persist.

## 4. Combat

![square](../assets/ui/square.svg) toggles fighting. Move into weapon reach to attack automatically; followers engage nearby threats. ![r](../assets/ui/r.svg) pauses combat for orders. Heavy steel needs strength equal to twice its weight. Weak or injured arms lengthen preparation and recovery. Mauls pierce armor; glaives reach farther; greatswords hit hard; anchor cleavers bleed. Guns use cartridges; bows use bolts.

Armor protects specific body locations. Piercing weapons ignore some armor; serrated blades bleed; staggering hits interrupt. Skills improve through use. Retreat from stronger opponents and use terrain.

## 5. Wounds & Rescue

Six body parts, blood and fatigue are separate. Head or chest failure knocks a survivor out. Bleeding can kill an unconscious character. ![triangle](../assets/ui/triangle.svg), Body, ![cross](../assets/ui/cross.svg) treats the selected survivor; ![cross](../assets/ui/cross.svg) near an injured ally opens First Aid, Carry and Recover Gear choices.

Dressings stop bleeding and restore some health. Sleeping restores the rest. A doctor charges for full treatment. Lost limbs require a mechanical replacement. Death is permanent; dismiss the body from Squad to free its slot.

## 6. Food & Sleep

Rations are eaten below forty hunger: first your pack, then a companion backpack or owned depot within three meters. Water supports farms; tonics restore blood and treat exposure. Starvation damages the chest.

An inn bed costs 25 silver and starts safe rest. Camp shelters are free. Sleeping reduces fatigue and restores wounds once bleeding stops and hunger is above twenty. Move to wake. The sun completes a day in thirty minutes of simulation; menus and tactical pause stop time.

## 7. Equipment

Six slots: weapon, torso, head, boots, legs, back. Pack ![cross](../assets/ui/cross.svg) equips; ![square](../assets/ui/square.svg) passes one to an ally; ![triangle](../assets/ui/triangle.svg) switches carried/worn gear. ![cross](../assets/ui/cross.svg) on worn gear removes it if space allows. WORN / TRY ON compares fit and actual bonuses.

Plate protects more but slows movement and hinders stealth. Cloth is light; travel gear favors weather or movement. Higher grades improve the same role. Torso armor covers chest/arms; headgear covers head; leg armor and boots have separate coverage chances. MOVE% is the worn speed bonus. Weight above capacity slows you further.

## 8. Merchants

Talk to a trader and choose Trade. ![horizontal](../assets/ui/horizontal.svg) switches buying and selling; ![l](../assets/ui/l.svg)/![r](../assets/ui/r.svg) filters supplies, weapons, armor or backpacks. ![cross](../assets/ui/cross.svg) trades one item. Shops have finite stocks and refresh daily with different gear.

Prices depend on quality, faction relations, local prosperity. Hostile factions refuse trade. Selling stolen goods back to their owner can expose you; Black Mesa fences accept them. The item details show its stats and effects before purchase.

## 9. Forging Gear

Visit a forge, then choose Gear forge from the expedition menu or smith dialogue. Choose slot, design, material and quality with ![horizontal](../assets/ui/horizontal.svg). The preview updates before you spend anything.

![cross](../assets/ui/cross.svg) on Forge makes the selected design. Metal, cloth and timber costs scale with material and grade; relic gear also needs a relic. Higher grades require smithing experience and research. Missing materials or a full pack cancel the transaction without charging you.

## 10. Crafting

Crafting recipes make supplies, refined metal, ammunition and prosthetics. A forge smelts ore and shapes weapons. A campfire cooks grain or meat with water. A research bench makes dressings.

Stand close to the station. The recipe screen lists costs and unlocks. Research consumes relics and silver in three tiers. Skills rise when crafting succeeds. A shared depot supplies worker jobs, but hand crafting uses the selected survivor's pack.

## 11. Your Outpost

Build outside settlement boundaries. Choose a structure and place it beside the selected character. Buildings cannot overlap; materials are charged only after validation.

Shelters heal; farms need water and yield grain; wind pumps irrigate nearby crops. Forges and benches unlock production. Depots hold sixteen clean stacks. ![cross](../assets/ui/cross.svg) opens storage; ![horizontal](../assets/ui/horizontal.svg) switches sides; ![square](../assets/ui/square.svg) moves a full stack. Camps attract raiders, so keep medicine and a retreat route.

## 12. Squad Jobs

![triangle](../assets/ui/triangle.svg), Squad: choose a survivor with ![horizontal](../assets/ui/horizontal.svg), then assign a job with ![cross](../assets/ui/cross.svg). Follow trails the assigned group leader; Hold stays put. Mine gathers local deposits; Farm waters and harvests; Medic treats injured allies.

Smelt and Cook use nearby stations and can collect ingredients from a nearby depot. Workers fetch water and ingredients, walk to stations, and store output; cooks keep two rations. Haul deposits raw cargo. Job status explains delays. Select a worker and move to interrupt their current action. Up to eight living members may join.

## 13. Crime & Stealth

![circle](../assets/ui/circle.svg) sneaks. Detection depends on stealth skill, equipment, distance and weather. Sneak and ![cross](../assets/ui/cross.svg) near a civilian to attempt pickpocketing. Owned salvage also counts as theft; locked containers require tools and time.

Witnesses create a faction penalty and bounty. A theft can fail, drawing guards. Stolen stacks retain an owner until fenced. Paying a bounty requires a town official. Guards may imprison a defeated wanted survivor; breaking out or paying bail is possible.

## 14. Factions

Compact guards roads and wells; Rust Caravans trade salvage. Shogunate markets sell lamellar and glaives. Ash monks sell medicine; Black Mesa fences stolen goods. Vultures raid; wild packs hunt.

Contracts raise standing; theft lowers it. The Factions ledger shows specialties and controlled towns. Hired guards cost 240 silver for escort or 180 for camp duty: one simulated day. They fight and bandage independently, keep their gear, wait outside interiors and return home on expiry.

## 15. Contracts

Marshals offer delivery, supply, hunt and relic contracts. Accept through dialogue; track objectives in the Journal. Deliveries require reaching another town. Supplies require the listed items. Hunts count victories after acceptance.

Return to the issuing settlement and claim in the Journal with ![cross](../assets/ui/cross.svg). Rewards grant silver, reputation and experience. Contracts persist in saves. Complete contracts, research relic technology and survey the frontier to advance the expedition legacy. ![square](../assets/ui/square.svg) locates an active contract on the atlas; ![cross](../assets/ui/cross.svg) there starts travel when ready.

## 16. Saves

Six manual slots plus autosave. ![start](../assets/ui/start.svg), Save or Load opens a ledger with name, day, party size and silver. Choose a slot; ![cross](../assets/ui/cross.svg) asks for confirmation. Save-and-title opens the ledger; choose and confirm a slot.

Saves use version, size and checksum validation and preserve a previous .bak file. Invalid files never replace your running expedition. Older saves through 0.5.2 remain loadable. Back them up before overwriting. Autosave is slot zero and is never used for manual saving.

## 17. Weather

Dust, rain, acid mist and snow change visibility, terrain colors and survival pressure. Storms reduce detection and ranged accuracy. Acid and cold build exposure outdoors; shelters and sealed gear protect you.

Tonics and rest help recover. Rain irrigates farms. The northern highlands are colder; the fen produces acid mist. Weather changes as time passes. The world ledger reports storms and settlement events so you can plan supplies and routes.

## 18. Captivity

Wanted survivors defeated by lawful guards may wake in town custody. They lose stolen cargo and must serve time, pay bail or attempt an escape. A conscious free companion can still be selected.

When imprisoned, movement is restricted to the holding area. ![cross](../assets/ui/cross.svg) opens the custody dialogue. Paying clears the local bounty. Escape attempts use lockpicking, may fail and raise the bounty. The prison timer, injuries and inventory persist through saving.

## 19. Building Interiors

Approach a house, inn, shop, tower or workshop door and press ![cross](../assets/ui/cross.svg) to enter. Walk around the room with ![dpad](../assets/ui/dpad.svg) or analog. Furniture blocks movement; use the aisles. ![cross](../assets/ui/cross.svg) near the door returns outside.

Counters open local trade. Beds cost 25 silver in town; owned beds are free. Workshop stations open forging, research or storage. Indoor time passes: hunger, bleeding and healing continue. Nearby followers in your group enter with you. Other groups and hired guards remain outside.

Save games preserve the building and indoor position. Switching squad members leaves the room. Interiors shelter you from weather; hostile occupants refuse entry.

## 20. Backpacks

Buy travel packs, medicine rolls, ore harnesses and bedroll packs from the BACKPACKS shop tab. Preview before buying. Other back gear rotates daily.

CARGO: travel 80%, medicine 85%, ore 60%, bedroll 70% of carried weight. Worn gear and carried people keep full weight. CARRY adds load allowance; LOAD previews a swap. All packs use the same 24 inventory slots.

FIGHT reduces melee attack/defence: travel -2, medicine 0, ore -7, bedroll -4. Bulky packs hurt stealth. Medicine aids first aid; bedrolls improve rest but are not beds. Unworn packs give no bonus.

## 21. The Copper Road

Copper Road is a voluntary expedition. Find the wreck between Dusk Haven and Copper Cross. Treat Sora, then escort her to Nell at the stores. Stay within 18m.

Repair the culvert after bringing Sora home: 3 timber, 1 iron bar and tools. Or pay Rell 450 for a toll truce; challenge him; or carry him alive to Nell. Each route changes trade and patrols. Claim payment once. Raid reprisals can follow capture or death. The ledger locates leads without issuing movement.

## 22. Orders & Groups

Orders sets Balanced, Defensive, Keep range or Hold fire. Defensive gives +18 defence but never attacks. Ranged allies retreat if a foe closes within 3.5m. Projectiles travel and hit walls or allies: clear your firing line.

Assign each survivor to one of three groups and choose its leader. In the atlas, hold ![r](../assets/ui/r.svg) and press ![cross](../assets/ui/cross.svg) for a group route. Four job priorities choose the first available task. Put Follow or Hold last. Manual movement pauses a queue; resume in Orders.

## 23. Camp Work & Fuel

Construction consumes materials when a foundation is placed. Stay beside it to build; moving cancels work. Resume from the nearby action or Camp ledger. Unfinished stations and beds cannot work.

Campfires and forges burn one charge per production action. Add clean timber for four charges or coal for ten. Stations lose a little condition with use. One timber repairs 35 condition. Town workshops supply their own fuel. Windpumps irrigate nearby farms. Queues skip unavailable jobs.

## 24. Trauma & Repair

Bleeding drains blood and can kill. Dressings stop bleeding and treat organic wounds; trauma still limits maximum health. Food and bed rest slowly restore that limit.

Mechanical characters and prosthetics need spare parts. Medicine and sleep cannot repair metal. The Care panel shows health, trauma and armor condition. Cloth restores equipment condition.

Raiders near the chain yard may carry a fallen survivor away. Escape takes time away from guards. Tools speed it up. Free allies can unlock captives. Escapees are remembered for a day.

## 25. Armor Layers

Use Armor Layers to fit a light body garment under outer armor. Weight must be five or less. Swaps preserve stolen ownership and fail safely if your pack is full.

Outer body covers 95% of chest hits and 65% of arm hits; headwear covers 85%, legwear 90%, boots 35%. An uncovered hit bypasses that piece. Blunt impacts use 72% of outer protection. Underlayers add reduced protection. Wear lowers protection to a minimum of 65%; maintain with cloth. Inspect both armor and movement before equipping.
